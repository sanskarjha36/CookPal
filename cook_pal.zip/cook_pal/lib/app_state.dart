import 'package:flutter/material.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  bool _Card1Liked = false;
  bool get Card1Liked => _Card1Liked;
  set Card1Liked(bool value) {
    _Card1Liked = value;
  }

  bool _Card2Liked = false;
  bool get Card2Liked => _Card2Liked;
  set Card2Liked(bool value) {
    _Card2Liked = value;
  }

  bool _Card3Liked = false;
  bool get Card3Liked => _Card3Liked;
  set Card3Liked(bool value) {
    _Card3Liked = value;
  }

  bool _Card4Liked = false;
  bool get Card4Liked => _Card4Liked;
  set Card4Liked(bool value) {
    _Card4Liked = value;
  }

  bool _Card5Liked = false;
  bool get Card5Liked => _Card5Liked;
  set Card5Liked(bool value) {
    _Card5Liked = value;
  }

  bool _Card6Liked = false;
  bool get Card6Liked => _Card6Liked;
  set Card6Liked(bool value) {
    _Card6Liked = value;
  }

  bool _toDark = false;
  bool get toDark => _toDark;
  set toDark(bool value) {
    _toDark = value;
  }

  bool _D1 = false;
  bool get D1 => _D1;
  set D1(bool value) {
    _D1 = value;
  }

  bool _D2 = false;
  bool get D2 => _D2;
  set D2(bool value) {
    _D2 = value;
  }

  bool _A1 = false;
  bool get A1 => _A1;
  set A1(bool value) {
    _A1 = value;
  }

  bool _A2 = false;
  bool get A2 => _A2;
  set A2(bool value) {
    _A2 = value;
  }

  bool _Di1 = false;
  bool get Di1 => _Di1;
  set Di1(bool value) {
    _Di1 = value;
  }

  bool _Di2 = false;
  bool get Di2 => _Di2;
  set Di2(bool value) {
    _Di2 = value;
  }

  int _LikedCount = 0;
  int get LikedCount => _LikedCount;
  set LikedCount(int value) {
    _LikedCount = value;
  }

  bool _AttStepsBool = false;
  bool get AttStepsBool => _AttStepsBool;
  set AttStepsBool(bool value) {
    _AttStepsBool = value;
  }

  int _Card1Count = 0;
  int get Card1Count => _Card1Count;
  set Card1Count(int value) {
    _Card1Count = value;
  }

  String _timer = '';
  String get timer => _timer;
  set timer(String value) {
    _timer = value;
  }

  String _Card1Hardness = '';
  String get Card1Hardness => _Card1Hardness;
  set Card1Hardness(String value) {
    _Card1Hardness = value;
  }

  bool _IngCh1 = false;
  bool get IngCh1 => _IngCh1;
  set IngCh1(bool value) {
    _IngCh1 = value;
  }

  bool _IngCh2 = false;
  bool get IngCh2 => _IngCh2;
  set IngCh2(bool value) {
    _IngCh2 = value;
  }

  bool _True1 = false;
  bool get True1 => _True1;
  set True1(bool value) {
    _True1 = value;
  }

  bool _True2 = false;
  bool get True2 => _True2;
  set True2(bool value) {
    _True2 = value;
  }

  bool _ActiveP1 = false;
  bool get ActiveP1 => _ActiveP1;
  set ActiveP1(bool value) {
    _ActiveP1 = value;
  }

  bool _ActiveP2 = false;
  bool get ActiveP2 => _ActiveP2;
  set ActiveP2(bool value) {
    _ActiveP2 = value;
  }

  bool _ActiveP3 = false;
  bool get ActiveP3 => _ActiveP3;
  set ActiveP3(bool value) {
    _ActiveP3 = value;
  }

  bool _True3 = false;
  bool get True3 => _True3;
  set True3(bool value) {
    _True3 = value;
  }

  String _UserName = '';
  String get UserName => _UserName;
  set UserName(String value) {
    _UserName = value;
  }

  String _UserEmail = '';
  String get UserEmail => _UserEmail;
  set UserEmail(String value) {
    _UserEmail = value;
  }

  String _UserPassword = '';
  String get UserPassword => _UserPassword;
  set UserPassword(String value) {
    _UserPassword = value;
  }

  String _UserPfp = '';
  String get UserPfp => _UserPfp;
  set UserPfp(String value) {
    _UserPfp = value;
  }

  bool _S1True = false;
  bool get S1True => _S1True;
  set S1True(bool value) {
    _S1True = value;
  }

  bool _S2True = false;
  bool get S2True => _S2True;
  set S2True(bool value) {
    _S2True = value;
  }

  bool _S1ATrue = false;
  bool get S1ATrue => _S1ATrue;
  set S1ATrue(bool value) {
    _S1ATrue = value;
  }

  bool _S1GTrue = false;
  bool get S1GTrue => _S1GTrue;
  set S1GTrue(bool value) {
    _S1GTrue = value;
  }

  bool _S1DTrue = false;
  bool get S1DTrue => _S1DTrue;
  set S1DTrue(bool value) {
    _S1DTrue = value;
  }

  bool _ProfileTrue1 = false;
  bool get ProfileTrue1 => _ProfileTrue1;
  set ProfileTrue1(bool value) {
    _ProfileTrue1 = value;
  }

  bool _CheckBool1 = false;
  bool get CheckBool1 => _CheckBool1;
  set CheckBool1(bool value) {
    _CheckBool1 = value;
  }

  bool _Gtrue3 = false;
  bool get Gtrue3 => _Gtrue3;
  set Gtrue3(bool value) {
    _Gtrue3 = value;
  }
}
