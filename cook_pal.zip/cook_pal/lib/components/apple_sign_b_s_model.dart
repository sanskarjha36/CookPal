import '/flutter_flow/flutter_flow_util.dart';
import 'apple_sign_b_s_widget.dart' show AppleSignBSWidget;
import 'package:flutter/material.dart';

class AppleSignBSModel extends FlutterFlowModel<AppleSignBSWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
