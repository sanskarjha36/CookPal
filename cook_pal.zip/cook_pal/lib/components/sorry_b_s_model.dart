import '/flutter_flow/flutter_flow_util.dart';
import 'sorry_b_s_widget.dart' show SorryBSWidget;
import 'package:flutter/material.dart';

class SorryBSModel extends FlutterFlowModel<SorryBSWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
