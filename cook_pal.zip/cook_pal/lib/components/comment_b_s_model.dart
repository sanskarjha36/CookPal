import '/flutter_flow/flutter_flow_util.dart';
import 'comment_b_s_widget.dart' show CommentBSWidget;
import 'package:flutter/material.dart';

class CommentBSModel extends FlutterFlowModel<CommentBSWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
