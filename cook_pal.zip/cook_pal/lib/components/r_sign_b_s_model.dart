import '/flutter_flow/flutter_flow_util.dart';
import 'r_sign_b_s_widget.dart' show RSignBSWidget;
import 'package:flutter/material.dart';

class RSignBSModel extends FlutterFlowModel<RSignBSWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
