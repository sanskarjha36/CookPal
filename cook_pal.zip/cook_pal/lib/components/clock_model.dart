import '/flutter_flow/flutter_flow_util.dart';
import 'clock_widget.dart' show ClockWidget;
import 'package:flutter/material.dart';

class ClockModel extends FlutterFlowModel<ClockWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
