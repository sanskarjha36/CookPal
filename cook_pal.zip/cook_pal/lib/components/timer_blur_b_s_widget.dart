import '/components/clock_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'timer_blur_b_s_model.dart';
export 'timer_blur_b_s_model.dart';

class TimerBlurBSWidget extends StatefulWidget {
  const TimerBlurBSWidget({super.key});

  @override
  State<TimerBlurBSWidget> createState() => _TimerBlurBSWidgetState();
}

class _TimerBlurBSWidgetState extends State<TimerBlurBSWidget>
    with TickerProviderStateMixin {
  late TimerBlurBSModel _model;

  final animationsMap = <String, AnimationInfo>{};

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => TimerBlurBSModel());

    animationsMap.addAll({
      'clockOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          VisibilityEffect(duration: 1.ms),
          ShakeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 1500.0.ms,
            hz: 5,
            offset: const Offset(5.0, 0.0),
            rotation: 0.087,
          ),
        ],
      ),
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: const AlignmentDirectional(0.0, 1.0),
      child: Container(
        width: double.infinity,
        height: 300.0,
        decoration: const BoxDecoration(),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(0.0),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: 5.0,
              sigmaY: 5.0,
            ),
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                color: Color(0x0014181B),
              ),
              child: wrapWithModel(
                model: _model.clockModel,
                updateCallback: () => safeSetState(() {}),
                child: const ClockWidget(),
              ).animateOnPageLoad(animationsMap['clockOnPageLoadAnimation']!),
            ),
          ),
        ),
      ),
    );
  }
}
