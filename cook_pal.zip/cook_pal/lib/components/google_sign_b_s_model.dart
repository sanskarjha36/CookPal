import '/flutter_flow/flutter_flow_util.dart';
import 'google_sign_b_s_widget.dart' show GoogleSignBSWidget;
import 'package:flutter/material.dart';

class GoogleSignBSModel extends FlutterFlowModel<GoogleSignBSWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
