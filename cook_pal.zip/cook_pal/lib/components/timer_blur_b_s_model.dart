import '/components/clock_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'timer_blur_b_s_widget.dart' show TimerBlurBSWidget;
import 'package:flutter/material.dart';

class TimerBlurBSModel extends FlutterFlowModel<TimerBlurBSWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for Clock component.
  late ClockModel clockModel;

  @override
  void initState(BuildContext context) {
    clockModel = createModel(context, () => ClockModel());
  }

  @override
  void dispose() {
    clockModel.dispose();
  }
}
